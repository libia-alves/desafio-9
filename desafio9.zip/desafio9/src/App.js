import React from 'react';
import './App.css';
import Formulario from './components/formulario';

function App() {
  return (
    <div className="App">
      <header className="App-header">
          <Formulario />
      </header>
    </div>
  );
}

export default App;
